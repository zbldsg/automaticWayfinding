<script setup lang="ts">
import {ref, onMounted} from "vue";
import * as THREE from "three";
import AStar from "javascript-astar";

import {onWindowResize} from "./Common/resize";
import {initAll} from "./Init/init";
import {generateFloor} from "./Generate/floor";

const renderers = {
  renderer: null,
  labelRenderer: null,
};

const current = {
  scene: null,
  camera: null,
  orbitControls: null,
  data: null,
};

let dom;

// 所有场景List
const baseSceneData = {
  id: null,
  name: null,
  path: "./model/city.glb",
  init: false,
  camera: null,
  control: null,
  scene: null,
  sceneObject: null,
};

const menu = ref({
  display: true,
});

onMounted(() => {
  dom = document.querySelector("#test");

  window.onresize = () => {
    onWindowResize(current.camera, renderers.renderer, dom);
  };

  init();
});

function init() {
  let data = {...baseSceneData};
  initAll(renderers, data, dom, current);
  // generateFloor(data);
  initGrid();
  initLine();
  animate();
}

function animate() {
  render();
  requestAnimationFrame((time) => {
    animate();
  });
}

function render() {
  renderers.renderer.render(current.scene, current.camera);
  renderers.labelRenderer.render(current.scene, current.camera);
}

function initLine() {

  const gridHelper = new THREE.GridHelper(200, 200);
  current.scene.add(gridHelper);

  let length = 300;
  let flex = 2;
  let box = new THREE.BoxGeometry(1, 1, 1);
  let material = new THREE.MeshBasicMaterial({color: 0xC0C0C0});
  let group = new THREE.Group();

  for (let i = 0; i < length / 10; i++) {
    for (let j = 0; j < length / 10; j++) {
      let salt = randomNum(1, 5);
      if (salt <= flex) {
        let cube = new THREE.Mesh(box, material);
        // 这里x和y 都要加上0.5 也就是box大小的一半, 防止box放在4个格子中间
        cube.position.set(10 * j - length / 2 + .5, 0.5, 10 * i - length / 2 + .5);
        group.add(cube);
      }
    }
  }

  current.scene.add(group)
}

function randomNum(minNum, maxNum) {
  switch (arguments.length) {
    case 1:
      return parseInt(Math.random() * minNum + 1, 10);
      break;
    case 2:
      return parseInt(Math.random() * (maxNum - minNum + 1) + minNum, 10);
      break;
    default:
      return 0;
      break;
  }
}

function initGrid() {


//   const geometry = new THREE.BoxGeometry(1, 1, 1)
//   const material = new THREE.MeshBasicMaterial({color: 0xC0C0C0})
//   let count = 15;
//   let group = new THREE.Group();
//   for (let i = 0; i < count; i++) {
//     const box = new THREE.Mesh(geometry, material)
//     let num = Math.floor(Math.random() * 10) + 1
//     let num2 = Math.floor(Math.random() * 10) + 1
//     box.position.set(i % 2 > 0 ? -num : num, .5, i % 3 > 0 ? -num2 : num2)
//
//     group.add(box)
//   }
//   current.scene.add(group)
//
//
  // 创建一个图,二维数组
  const graph = new AStar.Graph([
    [1, 1, 1, 1, 0],
    [1, 0, 0, 1, 0],
    [1, 1, 1, 1, 0],
    [0, 0, 0, 1, 1]
  ], {diagonal: false});

  // 使用 A* 算法寻找路径
  const startNode = graph.grid[0][0];
  const endNode = graph.grid[3][4];

  // 执行A*搜索
  const result = AStar.astar.search(graph, startNode, endNode);
  console.log(result, '我醉了')

}
</script>

<template>
  <div class="test" id="test"></div>
</template>

<style lang="less">
.test {
  width: 100vw;
  height: 100vh;
  overflow: hidden;
  background-color: #070a2b;
  background-size: 100%;
}
</style>
